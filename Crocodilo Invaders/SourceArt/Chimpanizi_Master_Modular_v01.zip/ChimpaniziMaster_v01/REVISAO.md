# Revisão do master v01

## Verificações automáticas executadas

- 19 PNGs recortados recompostos na ordem e nos offsets do JSON: **0 pixels diferentes** em relação ao master.
- Alpha dos PNGs: **somente 0 e 255**.
- Cores fora da paleta nomeada: **0**; 26 cores usadas.
- Todos os pivôs locais dentro dos limites de seus PNGs.
- Master não toca a borda do canvas; caixa opaca documentada.
- Fontes e previews fora de `Assets`; nenhuma cena ou prefab existente modificado.

Resultados repetíveis em `qa_report.json` e assertions do gerador.

## Revisão visual realizada

| Ponto | Evidência e resultado |
| --- | --- |
| Banana com braços/pernas, sem cabeça de chimpanzé externa | `master_review.png` e master nativo: corpo amarelo curvo, polpa com expressão, mãos/pés de primata |
| Leitura em 1× e ampliada | `master_review.png` e `master_x4.png`: casca, mãos, pé e expressão visíveis |
| Modularidade real | `parts_contact_sheet.png`: 19 imagens distintas; corpo/polpa completos atrás dos detalhes |
| Encaixes da pose atual | Master nativo e `master_review.png`: sem frestas transparentes visíveis entre membros e corpo |
| Silhueta | `silhouette_x3.png`: braço elevado e braço frontal têm espaços negativos distintos; pés separados |
| Escala de pixels em relação ao elenco | `native_scale_comparison.png`: referência para revisão, sem afirmar tamanho definitivo em Unity |
| Contraste no ambiente | `forest_context_mockup.png`: banana amarela se separa do fundo verde-azulado; membros oliva têm menor contraste, compensado por contorno e massas simples |
| Articulações documentadas | `joint_points.png` e sockets do JSON |

## Ainda não verificável nesta etapa

- Jitter, retorno ao idle e igualdade entre início/fim de ataque: **não se aplicam**, pois só existe uma pose estática.
- Todas as amplitudes dos cotovelos/joelhos e passagem da mão entre cipós: exigem key poses futuras. Os recortes atuais não são um rig pronto com rotação arbitrária.
- Avisos, spawn de cipós e áreas seguras: ataques ainda não produzidos.
- Câmera, colisões e legibilidade em uma partida real: não houve integração ou teste na Unity.
- Aprovação artística e nome final: dependem da revisão do usuário. Não marcar esta proposta como aprovada.
