# Chimpanizi Bananini — master modular F1 v01

19/10/2026. **Proposta estática para revisão do usuário. Ainda não aprovada.**

Primeira forma: uma banana com membros de chimpanzé. Não há cabeça de chimpanzé saindo da fruta; a polpa recebe os olhos e a boca. A casca amarela é a massa principal. Membros verde-oliva, mãos e pés castanhos retomam a referência fornecida. Uma mão está em preensão acima do corpo, a outra fecha o punho na direção do Croc. O personagem encara a esquerda em três quartos.

Arte desenhada por código raster determinístico (Pillow/numpy), seguindo o método modular descrito em `GUSINI_BOSS_COMO_FOI_FEITO.md`. Não é recorte de imagem gerada, nem conversão da foto de referência.

## Conteúdo

| Arquivo/pasta | Uso |
| --- | --- |
| `master/chimpanizi_p1_master.png` | Master montado, canvas 256 × 256, transparência real |
| `parts/` | 19 PNGs nativos recortados, sem etiquetas ou marcadores |
| `chimpanizi_p1_master.json` | Paleta, hierarquia, offsets, pivôs, ordem de desenho, sockets e hashes |
| `previews/master_review.png` | Revisão em 1× e 3× |
| `previews/parts_contact_sheet.png` | Todas as peças e seus pivôs |
| `previews/joint_points.png` | Marcadores de articulação e preensão, apenas para revisão |
| `previews/silhouette_x3.png` | Silhueta sobre fundo claro |
| `previews/native_scale_comparison.png` | Comparação na escala dos pixels nativos com Croc e Gusini |
| `previews/forest_context_mockup.png` | Composição ilustrativa sobre a floresta proposta; não é captura da Unity |
| `qa_report.json` | Verificações automáticas |
| `REVISAO.md` | Evidência visual e limites desta entrega |
| `tools/master.py` | Gerador reproduzível, também no projeto em `Tools/Art/Chimpanizi/master.py` |

## Peças e articulação

- **Corpo-âncora:** `body`, a banana curva com ponta escura. Preserva uma massa contínua atrás dos encaixes.
- **Fruta e casca:** `stalk`, `pulp_face`, `peel_front_flap`, `peel_back_flap`. As abas têm raízes próprias para futuras poses.
- **Atuação facial:** `eyes_brows` e `mouth`. Podem ganhar variações localizadas sem redesenhar o corpo.
- **Cada braço:** upper arm → forearm → hand. Ombro, cotovelo e pulso documentados. A mão traseira tem uma abertura para preensão; a dianteira é o punho base, não uma mão aberta pronta para agarrar.
- **Cada perna:** thigh → shin → foot. Quadril, joelho e tornozelo documentados. Pés com dedão oponível.

As peças têm área sobreposta nos encaixes desta pose. Grandes mudanças de direção/rotação exigirão poses específicas e revisão das subpinturas: este master não promete amplitude ilimitada de um rig automático. Não esticar ou suavizar os PNGs para compensar articulações.

## Convenções técnicas

- Canvas fixo do master: **256 × 256 px**. Silhueta atual: **200 × 232 px**, caixa opaca `[20, 11, 220, 243]` com máximos exclusivos.
- Pivô global no corpo: **(132,154)**, origem no topo/esquerda, Y para baixo. Unity normalizado: **(0,515625; 0,3984375)**.
- Cada peça recortada tem `offset_in_canvas_px`, `pivot_canvas_px`, `pivot_local_px`, `pivot_unity_normalized`, `parent`, `joint_from_parent_px` e `sorting_order`.
- Montagem estática: desenhar por `sorting_order`, colocando cada PNG em `offset_in_canvas_px`. A hierarquia lógica está em `parent`; a ordem de render não é a ordem de criação dos nós.
- Para montar nós em Unity: posição do pivô relativa ao pai = `(dx/PPU, -dy/PPU)` a partir de `joint_from_parent_px`. O sprite do nó usa seu pivô local. A raiz usa o pivô global. Não aplicar simultaneamente offsets do recorte e do pivô — são duas formas alternativas de reconstrução.
- Os sockets de preensão são pontos de referência, não hitboxes. Nenhum cipó está embutido no sprite. O cipó deverá ser entidade própria com seu vínculo à mão.
- 26 cores usadas da paleta nomeada. Contorno `(13,13,21)`, luz de cima/esquerda, sombreamento em blocos. Sem antialiasing, blur ou subpixel; alpha apenas 0/255.
- Importação futura sugerida: Point, Full Rect, sem mipmaps, Compression None. **PPU 100 provisório**, a confirmar no enquadramento real. Não alterar o PPU do cenário ou de outros packs para acomodar este boss.
- As previews ampliadas não são sprites de runtime. A comparação nativa não comprova escala final no mundo; Croc tem compensação de escala no prefab atual. O mockup usa Croc 2× e boss 3× para estudo de composição, sem simular a câmera final ou demonstrar conexão ao cipó.

## Próxima etapa, depois da revisão deste master

Confirmar aparência, escala e postura; então produzir poses de preensão/balanço e o idle a partir destas peças. Manter canvas e pivô entre clips; documentar durações e eventos nos JSONs. Trajetória pelo mapa, balanço global e shake pertencem à Unity. Cipós ofensivos e seus avisos serão assets próprios.

Não foram definidos número de fases, transformação final, ataques adicionais, cura, HP ou dano. Não foram produzidos animação, spritesheet animada, áudio, hitboxes, rig/Animator, cena ou implementação Unity.

## Reproduzir

Dependências: Python 3, Pillow e numpy. O script localiza o ancestral do projeto que contém `Assets/` e `SourceArt/`; execute-o dentro da estrutura deste projeto. Não depende de scipy, de diretórios antigos do Claude nem de geração de imagem.

Exemplo a partir da raiz do repositório:

```powershell
python "Crocodilo Invaders/Tools/Art/Chimpanizi/master.py"
```

O gerador recria os PNGs/JSONs desta v01 e as cópias das previews em `Docs/ArtPreviews/ChimpaniziMaster_v01`. Para revisar uma v02, duplique/versione o gerador e a saída; não sobrescreva um master já aprovado.
