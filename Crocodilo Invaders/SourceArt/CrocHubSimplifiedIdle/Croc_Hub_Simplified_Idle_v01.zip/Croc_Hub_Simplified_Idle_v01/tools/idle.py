# IDLE: 6 quadros a 6 FPS (1 s por ciclo) montados SÓ com os módulos + deslocamentos de 1 px.
# Respiração: tronco e braços sobem 1 px (inspira), a cabeça acompanha 1 quadro depois e desce 1 quadro depois
# (compensação/arrasto), quadril e pernas fixos, botas no chão.
import numpy as np
from PIL import Image
import modules as MO

M, H, W, K = MO.M, MO.H, MO.W, MO.K
FPS = 6
# (dy da cabeça, dy do tronco, dy dos braços) — y para baixo; −1 = sobe 1 px
TABLE = [
    dict(name='repouso', head=0, torso=0, arms=0),
    dict(name='inspira', head=0, torso=-1, arms=-1),
    dict(name='topo', head=-1, torso=-1, arms=-1),
    dict(name='segura', head=-1, torso=-1, arms=-1),
    dict(name='expira', head=-1, torso=0, arms=0),
    dict(name='assenta', head=0, torso=0, arms=0),
]


def offsets(fr):
    return {'head': (fr['head'], 0), 'torso': (fr['torso'], 0), 'arm_front': (fr['arms'], 0), 'arm_back': (fr['arms'], 0)}


# ---------------------------------------------------------------- piscada (overlay preso à cabeça)
EYE_Y = (2, 3, 4, 5)        # tons amarelos do olho no master
def eyelids():
    yell = {(239, 188, 98), (209, 152, 71)}
    eye = np.zeros((H, W), bool)
    for y in range(15, 20):
        for x in range(18, 27):
            if tuple(M[y, x, :3]) in yell: eye[y, x] = True
    lid_col = (56, 78, 46); lid_lo = (65, 90, 52)
    half = np.zeros_like(M); closed = np.zeros_like(M)
    ys, xs = np.where(eye)
    top = ys.min()
    for y, x in zip(ys, xs):
        # meio fechado: pálpebra (pele) na linha de cima, borda da pálpebra (contorno) na do meio, olho embaixo
        if y == top: half[y, x] = (*lid_col, 255)
        elif y == top + 1: half[y, x] = (*K, 255)
        # fechado: pálpebra inteira com a linha dos cílios (contorno) na base
        closed[y, x] = (*lid_col, 255) if y < ys.max() else (*K, 255)
    return eye, half, closed


EYE, LID_HALF, LID_CLOSED = eyelids()
MO.autofill_gaps([offsets(f) for f in TABLE])
assert (MO.compose() == M).all()


def frame(i, blink=None):
    return MO.compose(offsets(TABLE[i]), blink=blink)


if __name__ == '__main__':
    fr = [frame(i) for i in range(len(TABLE))]
    for i, f in enumerate(fr):
        d = (f != M).any(-1)
        # buracos: pixel transparente com vizinhos opacos à esquerda e à direita (ou em cima e embaixo) que no master era opaco
        op = f[..., 3] > 0
        hole = ~op & MO.OP & ((np.roll(op, 1, 1) & np.roll(op, -1, 1)) | (np.roll(op, 1, 0) & np.roll(op, -1, 0)))
        print(i, TABLE[i]['name'], 'px diferentes do master:', int(d.sum()), 'buracos:', int(hole.sum()))
    print('olho px', int(EYE.sum()))
