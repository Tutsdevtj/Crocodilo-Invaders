import numpy as np
from PIL import Image, ImageDraw
im = np.array(Image.open('ref.png').convert('RGB')).astype(int)
xl = np.load('/tmp/claude-0/xl.npy'); yl = np.load('/tmp/claude-0/yl.npy')
H, W = len(yl) - 1, len(xl) - 1
out = np.zeros((H, W, 3), int); var = np.zeros((H, W))
for j in range(H):
    for i in range(W):
        y0, y1, x0, x1 = yl[j], yl[j + 1], xl[i], xl[i + 1]
        iy, ix = max(1, (y1 - y0) // 4), max(1, (x1 - x0) // 4)
        blk = im[y0 + iy:y1 - iy, x0 + ix:x1 - ix].reshape(-1, 3)
        out[j, i] = np.median(blk, 0)
        var[j, i] = blk.std(0).mean()
np.save('/tmp/claude-0/cells.npy', out); np.save('/tmp/claude-0/cellvar.npy', var)
Image.fromarray(out.astype(np.uint8)).resize((W * 12, H * 12), Image.NEAREST).save('/tmp/claude-0/cells_x12.png')
# sobreposição da grade no original (recorte do rosto)
ov = Image.open('ref.png').convert('RGB'); d = ImageDraw.Draw(ov)
for x in xl: d.line([(x, 0), (x, 1536)], fill=(255, 0, 255))
for y in yl: d.line([(0, y), (1024, y)], fill=(255, 0, 255))
ov.crop((380, 380, 880, 720)).resize((1000, 680), Image.NEAREST).save('/tmp/claude-0/grid_face.png')
print(H, W, 'cells with high variance:', int((var > 18).sum()))
