import numpy as np
from PIL import Image
a = np.load('/tmp/claude-0/raw_master.npy').copy()
pal = np.load('/tmp/claude-0/pal.npy')
H, W = a.shape[:2]
K = (10, 12, 16)
def key(c): return tuple(int(v) for v in c)
# funde cores raras sem papel visual próprio
counts = {key(c): int(((a[..., :3] == c).all(-1) & (a[..., 3] > 0)).sum()) for c in pal}
merge = {(94, 88, 84): (73, 61, 42), (114, 135, 74): (112, 115, 58)}
for s, d in merge.items():
    m = (a[..., :3] == s).all(-1) & (a[..., 3] > 0); a[m, :3] = d
protect = {(253, 233, 145), (239, 188, 98), (182, 167, 152), (137, 127, 119), (209, 152, 71), K}
# limpeza: pixel isolado (sem vizinho 4-conectado da mesma cor) assume a cor dominante ao redor
for it in range(2):
    out = a.copy(); n = 0
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            if a[y, x, 3] == 0: continue
            c = key(a[y, x, :3])
            if c in protect: continue
            nb = [key(a[y + dy, x + dx, :3]) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)) if a[y + dy, x + dx, 3] > 0]
            if c in nb or len(nb) < 3: continue
            cand = [v for v in nb if v != K] or nb
            best = max(set(cand), key=cand.count)
            if cand.count(best) >= 2: out[y, x, :3] = best; n += 1
    a = out; print('pass', it, 'fixed', n)
# recorte para o canvas nativo 48x72 (pés na linha 70, pivô no chão = y 71)
can = np.zeros((72, 48, 4), np.uint8)
can[2:2 + (83 - 14), 3:3 + (54 - 12)] = a[14:83, 12:54]
Image.fromarray(can).save('/tmp/claude-0/master_v1.png')
op = can[..., 3] > 0; ys, xs = np.where(op); print('bbox', xs.min(), xs.max(), ys.min(), ys.max())
cols, cnt = np.unique(can[op][:, :3], axis=0, return_counts=True); print(len(cols), 'cores')
for c, k in zip(cols, cnt): print(tuple(c), k)
bg = np.zeros_like(can); bg[..., :3] = (150, 190, 230); bg[..., 3] = 255; bg[op] = can[op]
Image.fromarray(bg).resize((48 * 10, 72 * 10), Image.NEAREST).save('/tmp/claude-0/master_v1_x10.png')
