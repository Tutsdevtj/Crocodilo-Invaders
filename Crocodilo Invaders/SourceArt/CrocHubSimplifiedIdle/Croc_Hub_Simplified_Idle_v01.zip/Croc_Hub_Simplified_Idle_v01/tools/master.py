import numpy as np, json
from PIL import Image
from scipy.cluster.vq import kmeans2
from scipy import ndimage
c = np.load('/tmp/claude-0/cells.npy').astype(float)
H, W = c.shape[:2]
bg = c.sum(2) <= 15
op = ~bg
# palette: k-means sobre células opacas, depois funde cores muito próximas
px_ = c[op]
cent, lab = kmeans2(px_, 22, seed=3, minit='++', iter=50)
cent = cent[np.unique(lab)]
changed = True
while changed:
    changed = False
    for i in range(len(cent)):
        for j in range(i + 1, len(cent)):
            if np.linalg.norm(cent[i] - cent[j]) < 13:
                cent[i] = (cent[i] + cent[j]) / 2; cent = np.delete(cent, j, 0); changed = True; break
        if changed: break
d = ((c[..., None, :] - cent[None, None]) ** 2).sum(-1)
idx = d.argmin(-1)
cent = np.round(cent).astype(int)
img = np.zeros((H, W, 4), np.uint8)
img[op, :3] = cent[idx[op]]; img[op, 3] = 255
np.save('/tmp/claude-0/raw_master.npy', img); np.save('/tmp/claude-0/pal.npy', cent)
ys, xs = np.where(op); print('bbox', xs.min(), xs.max(), ys.min(), ys.max(), 'size', xs.max()-xs.min()+1, ys.max()-ys.min()+1)
print(len(cent)); 
for k, col in enumerate(cent): print(k, tuple(col), int((idx[op] == k).sum()))
Image.fromarray(img).resize((W * 10, H * 10), Image.NEAREST).save('/tmp/claude-0/raw_master_x10.png')
