# Divisão modular mínima do novo B. Crocodilo (HUB) a partir do master nativo 48x72.
# Cada pixel opaco do master tem exatamente UM dono visível. A subpintura oculta (só o necessário para o
# idle de 1 px) fica por baixo de peças da frente e não aparece na pose neutra.
import numpy as np
from PIL import Image

M = np.array(Image.open('/home/claude/proj/crochub/out/master/croc_hub_master.png').convert('RGBA'))
H, W = M.shape[:2]
OP = M[..., 3] > 0
YY, XX = np.mgrid[0:H, 0:W]
K = (10, 12, 16)

# ---------------------------------------------------------------- donos (medidos no mapa de caracteres do master)
HEAD_ROWS = {28: (17, 41), 29: [(20, 28), (30, 40)], 30: [(21, 28), (36, 39)], 31: (22, 27), 32: (23, 26), 33: (24, 26)}
ARM_F = {29: 11, 30: 12, 31: 12, 32: 13, 33: 13, 34: 13, 35: 14, 36: 12, 37: 12, 38: 11, 39: 12, 40: 12, 41: 12, 42: 11,
         43: 8, 44: 10, 45: 9, 46: 9, 47: 9}
for y in range(48, 55): ARM_F[y] = 11
ARM_B_FROM = {**{y: 33 for y in range(34, 42)}, **{y: 34 for y in range(42, 55)}}

own = {n: np.zeros((H, W), bool) for n in ('head', 'torso', 'arm_front', 'arm_back', 'hips', 'leg_front', 'leg_back')}
for y in range(H):
    for x in range(W):
        if not OP[y, x]: continue
        if y <= 27: own['head'][y, x] = True; continue
        hr = HEAD_ROWS.get(y)
        if hr:
            rngs = hr if isinstance(hr, list) else [hr]
            if any(a <= x <= b for a, b in rngs): own['head'][y, x] = True; continue
        if y in ARM_F and x <= ARM_F[y]: own['arm_front'][y, x] = True; continue
        if y in ARM_B_FROM and x >= ARM_B_FROM[y]: own['arm_back'][y, x] = True; continue
        if y <= 40: own['torso'][y, x] = True; continue
        if y <= 50: own['hips'][y, x] = True; continue
        (own['leg_front'] if x <= 22 else own['leg_back'])[y, x] = True
assert sum(o.astype(int) for o in own.values()).max() == 1
assert (sum(o.astype(int) for o in own.values()) == OP).all()

ORDER = ['leg_back', 'leg_front', 'hips', 'arm_back', 'torso', 'head', 'arm_front']
RANK = {n: i for i, n in enumerate(ORDER)}
rank = np.full((H, W), -1)
for n, m in own.items(): rank[m] = RANK[n]

LAY = {}
for n, m in own.items():
    a = np.zeros_like(M); a[m] = M[m]; LAY[n] = a
NOTES = {}


def under(n, region, src, note):
    """subpintura: só onde está oculto na pose neutra (peça mais à frente cobre) e ainda vazio"""
    free = region & (rank > RANK[n]) & (LAY[n][..., 3] == 0) & OP
    LAY[n][free] = src[free]
    NOTES.setdefault(n, []).append((note, int(free.sum())))


def shifted(arr, dy, dx=0):
    out = np.zeros_like(arr)
    ys, xs = np.where(arr[..., 3] > 0)
    Y, X = ys + dy, xs + dx; ok = (Y >= 0) & (Y < H) & (X >= 0) & (X < W)
    out[Y[ok], X[ok]] = arr[ys[ok], xs[ok]]
    return out


# 1) quadril: a jaqueta continua 2 linhas para cima por baixo do tronco (o tronco sobe 1 px ao inspirar)
band = (YY >= 38) & (YY <= 40) & own['torso']
under('hips', band, M, 'jaqueta continua sob a borda inferior do tronco (respiração)')
# 2) tronco: gola/pescoço continuam para cima por baixo do queixo (a cabeça sobe 1 px)
#    usa o pixel do próprio tronco logo abaixo de cada coluna (continuação do pano, sem duplicar o contorno do queixo)
t = LAY['torso'].copy()
cont = np.zeros_like(M)
for x in range(W):
    col = np.where(own['torso'][:, x])[0]
    if not len(col): continue
    top = col.min()
    for k in (1, 2):
        if top - k >= 0: cont[top - k, x] = M[top, x] if tuple(M[top, x, :3]) != K else M[min(H - 1, top + 1), x]
under('torso', (YY >= 26) & (YY <= 34) & (cont[..., 3] > 0), cont, 'gola/pescoço continuam sob o queixo (cabeça sobe 1 px)')
# 3) braços: tronco tem a lateral do corpo sob a borda interna dos braços (por segurança no idle e na corrida futura)
side = np.zeros_like(M)
for y in range(29, 48):
    xs = np.where(own['torso'][y])[0]
    if not len(xs): continue
    x0, x1 = xs.min(), xs.max()
    for k in (1, 2):
        if x0 - k >= 0: side[y, x0 - k] = M[y, x0 + 1] if tuple(M[y, x0 + 1, :3]) != K else M[y, x0 + 2]
        if x1 + k < W: side[y, x1 + k] = M[y, x1 - 1] if tuple(M[y, x1 - 1, :3]) != K else M[y, x1 - 2]
under('torso', side[..., 3] > 0, side, 'lateral do tronco continua sob a borda interna dos braços')


def compose(off=None, blink=None, layers=None):
    off = off or {}; layers = layers or LAY
    o = np.zeros_like(M)
    for n in ORDER:
        a = shifted(layers[n], *off.get(n, (0, 0)))
        m = a[..., 3] > 0; o[m] = a[m]
        if n == 'head' and blink is not None:
            b = shifted(blink, *off.get('head', (0, 0))); mb = b[..., 3] > 0; o[mb] = b[mb]
    return o


REST = compose()
assert (REST == M).all(), 'remontagem difere do master'


def autofill_gaps(frame_offsets, movers_rank_min=None, max_iter=4):
    """fecha frestas que o idle abriria: um pixel opaco no master que fica transparente num quadro
    (com vizinhos opacos dos dois lados) recebe subpintura na peça de trás mais próxima (tronco, quadril ou
    pernas), com a cor da vizinha dessa peça; se encostar no vazio externo, vira contorno."""
    body = ['torso', 'hips', 'leg_front', 'leg_back']
    filled = 0
    for it in range(max_iter):
        new = 0
        for off in frame_offsets:
            f = compose(off)
            op = f[..., 3] > 0
            hole = ~op & OP & ((np.roll(op, 1, 1) & np.roll(op, -1, 1)) | (np.roll(op, 1, 0) & np.roll(op, -1, 0)))
            for y, x in zip(*np.where(hole)):
                best = None
                for r in range(1, 4):
                    for dy in range(-r, r + 1):
                        for dx in range(-r, r + 1):
                            Y, X = y + dy, x + dx
                            if not (0 <= Y < H and 0 <= X < W): continue
                            for n in body:
                                if own[n][Y, X] and (best is None or abs(dy) + abs(dx) < best[0]):
                                    best = (abs(dy) + abs(dx), n, Y, X)
                    if best: break
                if not best: continue
                _, n, Y, X = best
                if rank[y, x] <= RANK[n]: continue                       # só onde fica oculto no repouso
                touches_out = any(not OP[y + dy, x + dx] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)) if 0 <= y + dy < H and 0 <= x + dx < W)
                col = (*K, 255) if touches_out else M[Y, X]
                if LAY[n][y, x, 3] == 0:
                    LAY[n][y, x] = col; new += 1
        filled += new
        if not new: break
    NOTES.setdefault('auto', []).append(('frestas fechadas por subpintura nas juntas', filled))
    return filled
