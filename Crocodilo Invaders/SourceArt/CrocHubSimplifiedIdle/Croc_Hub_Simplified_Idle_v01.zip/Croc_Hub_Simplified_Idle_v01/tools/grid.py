# Inferência da grade irregular: programação dinâmica escolhe linhas de borda (espaçamento 12–21 px)
# que maximizam a força das bordas no perfil de gradiente, com leve penalidade por fugir do período médio.
import numpy as np
from PIL import Image

def profile(im, axis):
    d = np.abs(np.diff(im, axis=axis)).sum(2)
    g = d.sum(axis=0 if axis == 0 else 1) if False else (d.sum(1) if axis == 0 else d.sum(0))
    out = np.zeros(g.shape[0] + 1); out[1:] = g      # out[i] = força da borda ENTRE pixel i-1 e i
    return out

def dp_lines(g, period, lo=12, hi=21, lam=None):
    n = len(g)
    lam = lam if lam is not None else g.mean() * 0.15
    best = np.full(n, -1e18); prev = np.full(n, -1, int)
    for i in range(0, hi):                     # primeira linha livre perto do início
        best[i] = g[i]
    for i in range(n):
        if best[i] <= -1e17: continue
        for s in range(lo, hi + 1):
            j = i + s
            if j >= n: break
            v = best[i] + g[j] - lam * (s - period) ** 2
            if v > best[j]: best[j] = v; prev[j] = i
    end = int(np.argmax(best[n - hi:])) + n - hi
    lines = [end]
    while prev[lines[-1]] >= 0: lines.append(prev[lines[-1]])
    return lines[::-1]

if __name__ == '__main__':
    im = np.array(Image.open('ref.png').convert('RGB')).astype(int)
    gx = profile(im, 1); gy = profile(im, 0)
    xl = dp_lines(gx, 16.6); yl = dp_lines(gy, 16.35)
    print(len(xl), len(yl)); print(np.diff(xl)); print(np.diff(yl))
    np.save('/tmp/claude-0/xl.npy', np.array(xl)); np.save('/tmp/claude-0/yl.npy', np.array(yl))
