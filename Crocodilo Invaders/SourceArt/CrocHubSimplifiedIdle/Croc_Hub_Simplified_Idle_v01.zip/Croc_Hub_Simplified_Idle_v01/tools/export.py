# Exporta Croc_Hub_Simplified_Idle_v01: módulos, overlays, frames, sheet, GIFs, previews e manifesto.
import os, json, shutil
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import modules as MO
import idle as ID

OUT = '/home/claude/proj/crochub/out'
for d in ('master', 'modules', 'idle', 'previews', 'tools'): os.makedirs(f'{OUT}/{d}', exist_ok=True)
F8 = ImageFont.truetype('/mnt/user-data/uploads/Crocodilo Invaders/Assets/Fonts/PressStart2P/PressStart2P-Regular.ttf', 8)
M, H, W = MO.M, MO.H, MO.W
LIGHT = (214, 210, 200)
SCENE = np.array(Image.open('/home/claude/proj/base01/BaseArt_01_Parallax_v01/previews/base_parallax_preview.png').convert('RGBA'))


def on(a, bg=LIGHT):
    b = np.zeros_like(a); b[..., :3] = bg[:3]; b[..., 3] = 255; m = a[..., 3] > 0; b[m] = a[m]; return b


def on_scene(a, x0=520, y0=548):
    b = SCENE[y0:y0 + a.shape[0], x0:x0 + a.shape[1]].copy(); m = a[..., 3] > 0; b[m] = a[m]; return b


def up(a, k): return np.repeat(np.repeat(a, k, 0), k, 1)
def T(d, xy, s, c=(40, 30, 60)): d.text(xy, s, font=F8, fill=c)
def save(a, p):
    assert set(np.unique(a[..., 3])).issubset({0, 255}), p
    Image.fromarray(a).save(p)


# ---------------------------------------------------------------- pivôs (medidos no master; canto sup. esq. do pixel)
J = dict(ground=(24, 71), hips_center=(24, 47), hip_front=(16, 51), hip_back=(28, 51), torso_center=(24, 36), waist=(24, 41),
         neck_base=(25, 33), shoulder_front=(10, 33), shoulder_back=(35, 35), eye=(22, 17))
NODES = {   # nó: (pai, articulação, sprites)
    'CrocHub': (None, 'ground', []),
    'Hips': ('CrocHub', 'hips_center', ['hips']),
    'LegBack': ('Hips', 'hip_back', ['leg_back']),
    'LegFront': ('Hips', 'hip_front', ['leg_front']),
    'Torso': ('Hips', 'waist', ['torso']),
    'ArmBack': ('Torso', 'shoulder_back', ['arm_back']),
    'Head': ('Torso', 'neck_base', ['head', 'eyelid_half', 'eyelid_closed']),
    'ArmFront': ('Torso', 'shoulder_front', ['arm_front']),
}
SPRITE_NODE = {s: n for n, (_, _, ss) in NODES.items() for s in ss}
ORDER = MO.ORDER[:]                                   # leg_back, leg_front, hips, arm_back, torso, head, arm_front
ORDER.insert(ORDER.index('head') + 1, 'eyelid_half'); ORDER.insert(ORDER.index('eyelid_half') + 1, 'eyelid_closed')
LAYERS = dict(MO.LAY); LAYERS['eyelid_half'] = ID.LID_HALF; LAYERS['eyelid_closed'] = ID.LID_CLOSED

# ---------------------------------------------------------------- master e módulos
save(M, f'{OUT}/master/croc_hub_master.png')
spr = {}
for n in ORDER:
    L = LAYERS[n]; ys, xs = np.where(L[..., 3] > 0)
    x0, y0, x1, y1 = int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1
    save(L[y0:y1, x0:x1], f'{OUT}/modules/{n}.png')
    node = SPRITE_NODE[n]; jx, jy = J[NODES[node][1]]; w, h = x1 - x0, y1 - y0
    vis = int(MO.own[n].sum()) if n in MO.own else 0
    spr[n] = dict(file=f'modules/{n}.png', w=w, h=h, canvas_x=x0, canvas_y=y0, node=node, sorting_order=ORDER.index(n),
                  pivot_canvas_px=[jx, jy], pivot_local_px=[jx - x0, jy - y0],
                  unity_pivot=[round((jx - x0) / w, 6), round((y1 - jy) / h, 6)],
                  visible_pixels_at_rest=vis, hidden_underpaint_pixels=int((L[..., 3] > 0).sum()) - vis if n in MO.own else 0,
                  default_active=n not in ('eyelid_half', 'eyelid_closed'))

# ---------------------------------------------------------------- frames do idle (canvas 48x72 idêntico)
frames = [ID.frame(i) for i in range(len(ID.TABLE))]
for i, f in enumerate(frames): save(f, f'{OUT}/idle/croc_idle_{i:02d}.png')
blink_half = ID.frame(0, ID.LID_HALF); blink_closed = ID.frame(0, ID.LID_CLOSED)
save(blink_half, f'{OUT}/idle/croc_idle_blink_half.png'); save(blink_closed, f'{OUT}/idle/croc_idle_blink_closed.png')
sheet = np.concatenate(frames, 1); save(sheet, f'{OUT}/idle/croc_idle_sheet.png')
ms = int(1000 / ID.FPS)
def gif(fr_list, path, k=1, bg=LIGHT, scene=False, dur=ms):
    ims = []
    for f in fr_list:
        b = on_scene(f) if scene else on(f, bg)
        ims.append(Image.fromarray(up(b, k)).convert('RGB'))
    ims[0].save(path, save_all=True, append_images=ims[1:], duration=dur, loop=0)
gif(frames, f'{OUT}/idle/croc_idle.gif', 4)

# GIF de demonstração com piscada ocasional (independente da respiração): ~5 ciclos, piscada no 3º
seq, durs = [], []
for c in range(5):
    for i, f in enumerate(frames):
        if c == 2 and i == 2:
            for b, d in ((ID.frame(2, ID.LID_HALF), 60), (ID.frame(2, ID.LID_CLOSED), 100), (ID.frame(2, ID.LID_HALF), 60)):
                seq.append(b); durs.append(d)
        seq.append(f); durs.append(ms)
def gif2(fr_list, durs, path, k, scene=False):
    ims = [Image.fromarray(up(on_scene(f) if scene else on(f), k)).convert('RGB') for f in fr_list]
    ims[0].save(path, save_all=True, append_images=ims[1:], duration=durs, loop=0)
gif2(seq, durs, f'{OUT}/previews/idle_zoom.gif', 8)
# escala real: claro + cenário lado a lado
ims = []
for f in seq:
    a = on(f); b = on_scene(f)
    ims.append(Image.fromarray(np.concatenate([a, np.full((H, 8, 4), 255, np.uint8), b], 1)).convert('RGB'))
ims[0].save(f'{OUT}/previews/idle_actual_scale.gif', save_all=True, append_images=ims[1:], duration=durs, loop=0)

# ---------------------------------------------------------------- previews estáticas
PV = f'{OUT}/previews'
# master nativo: 1:1 sobre claro, cenário e xadrez
chk = np.zeros((H, W, 4), np.uint8); yy, xx = np.mgrid[0:H, 0:W]; c = ((xx // 4 + yy // 4) % 2 == 0)
chk[c] = (200, 200, 210, 255); chk[~c] = (160, 160, 175, 255)
ch_ = chk.copy(); m = M[..., 3] > 0; ch_[m] = M[m]
nat = np.concatenate([on(M), np.full((H, 4, 4), 255, np.uint8), on_scene(M), np.full((H, 4, 4), 255, np.uint8), ch_], 1)
Image.fromarray(nat).save(f'{PV}/master_native.png')
Image.fromarray(up(on(M), 10)).save(f'{PV}/master_zoom_nearest.png')

# original x master
ref = Image.open('/home/claude/proj/crochub/ref.png').convert('RGB')
xl = np.load('/tmp/claude-0/xl.npy'); yl = np.load('/tmp/claude-0/yl.npy')
# recorte do original correspondente ao canvas (células 9..56 em x, 12..83 em y)
rx0, rx1, ry0, ry1 = xl[9], xl[57], yl[12], yl[84]
rc = ref.crop((rx0, ry0, rx1, ry1)).resize((W * 8, H * 8), Image.LANCZOS)
cmp = Image.new('RGB', (W * 8 * 2 + 30, H * 8 + 30), (230, 228, 222)); d = ImageDraw.Draw(cmp); d.fontmode = '1'
cmp.paste(rc, (10, 24)); cmp.paste(Image.fromarray(up(on(M, (20, 20, 24)), 8)).convert('RGB'), (W * 8 + 20, 24))
T(d, (10, 6), 'ORIGINAL 1024x1536 (recorte, reduzido p/ comparar)'); T(d, (W * 8 + 20, 6), f'MASTER NATIVO {W}x{H} (x8, mesmo fundo)')
cmp.save(f'{PV}/original_vs_master.png')

# explodido
off = {'head': (-10, 0), 'torso': (-4, 0), 'arm_front': (-2, -8), 'arm_back': (-2, 8), 'hips': (2, 0), 'leg_front': (8, -3), 'leg_back': (8, 3)}
ex = np.zeros((H + 30, W + 24, 4), np.uint8)
for n in MO.ORDER:
    a = MO.shifted(LAYERS[n], off[n][0], off[n][1])
    a2 = np.zeros((H + 30, W + 24, 4), np.uint8); a2[12:12 + H, 12:12 + W] = a
    mm = a2[..., 3] > 0; ex[mm] = a2[mm]
exi = Image.fromarray(up(on(ex), 8)).convert('RGB'); d = ImageDraw.Draw(exi); d.fontmode = '1'
T(d, (6, 6), '7 MODULOS (afastados; inclui a subpintura oculta)')
exi.save(f'{PV}/modular_exploded.png')

# reconstruído + diferença
rest = MO.compose(); diff = (rest != M).any(-1)
dm = np.zeros_like(M); dm[..., :3] = 60; dm[..., 3] = 255; dm[M[..., 3] > 0] = (120, 120, 120, 255); dm[diff] = (255, 0, 0, 255)
rc2 = np.concatenate([on(M), np.full((H, 4, 4), 255, np.uint8), on(rest), np.full((H, 4, 4), 255, np.uint8), dm], 1)
im = Image.fromarray(up(rc2, 6)).convert('RGB'); d = ImageDraw.Draw(im); d.fontmode = '1'
T(d, (4, 4), 'MASTER'); T(d, (W * 6 + 28, 4), 'MODULOS MONTADOS'); T(d, (W * 12 + 52, 4), f'DIF: {int(diff.sum())} px', (255, 255, 255))
im.save(f'{PV}/modular_reconstructed.png')

# contact sheet do idle: frames x6 (claro), x6 (cenário), linha 1:1, piscada
tiles = frames + [blink_half, blink_closed]
labs = [f'{i:02d} {ID.TABLE[i]["name"]}' for i in range(len(frames))] + ['piscada 1/2', 'piscada']
k = 5; tw = W * k + 8
cs = Image.new('RGB', (tw * len(tiles) + 8, H * k * 2 + 60 + H + 30), (230, 228, 222)); d = ImageDraw.Draw(cs); d.fontmode = '1'
for i, (f, lb) in enumerate(zip(tiles, labs)):
    x = 8 + i * tw
    T(d, (x, 4), lb)
    cs.paste(Image.fromarray(up(on(f), k)).convert('RGB'), (x, 16))
    cs.paste(Image.fromarray(up(on_scene(f), k)).convert('RGB'), (x, 16 + H * k + 8))
    cs.paste(Image.fromarray(on(f)).convert('RGB'), (x, 16 + H * k * 2 + 30))
    cs.paste(Image.fromarray(on_scene(f)).convert('RGB'), (x + W + 6, 16 + H * k * 2 + 30))
T(d, (8, 16 + H * k * 2 + 18), 'tamanho real 1:1 (fundo claro e cenario)')
cs.save(f'{PV}/idle_contact_sheet.png')

# checagem de transparência: alfa, xadrez, fundos branco/preto/cenário
alpha = np.zeros_like(M); alpha[..., 3] = 255; alpha[M[..., 3] > 0, :3] = 255
row = [on(M, (255, 255, 255)), on(M, (0, 0, 0)), ch_, on_scene(M), alpha]
tc = np.concatenate(sum([[r, np.full((H, 4, 4), 128, np.uint8)] for r in row], [])[:-1], 1)
im = Image.fromarray(up(tc, 5)).convert('RGB'); d = ImageDraw.Draw(im); d.fontmode = '1'
for i, s in enumerate(['branco', 'preto', 'xadrez', 'cenario', 'alfa']): T(d, (4 + i * (W * 5 + 20), 4), s, (255, 60, 60))
im.save(f'{PV}/transparency_check.png')

# ---------------------------------------------------------------- manifesto
nodes = {}
for n, (par, j, sprites) in NODES.items():
    p = J[j]; pp = J[NODES[par][1]] if par else None
    loc = [p[0] - pp[0], p[1] - pp[1]] if pp else [0, 0]
    nodes[n] = dict(parent=par, joint=j, joint_canvas_px=list(p), local_px_ydown=loc, local_unity_px=[loc[0], -loc[1]],
                    local_units_ppu100=[round(loc[0] / 100, 4), round(-loc[1] / 100, 4)], sprites=sprites)
idle_frames = []
for i, fr in enumerate(ID.TABLE):
    t, hd, ar = fr['torso'], fr['head'], fr['arms']
    idle_frames.append(dict(index=i, name=fr['name'], duration_ms=ms, file=f'idle/croc_idle_{i:02d}.png',
                            canvas_offset_px_ydown=dict(head=hd, torso=t, arm_front=ar, arm_back=ar),
                            node_local_offset_unity_px=dict(Torso=-t, Head=-(hd - t), ArmFront=-(ar - t), ArmBack=-(ar - t))))
man = dict(
    character='B. Crocodilo — versão HUB simplificada', source_reference=dict(file='imagem aprovada 1024x1536 RGB, fundo preto', inferred_cell_px='≈16,3–16,6 px (irregular, 12–20)'),
    canvas=[W, H], pivot_character=list(J['ground']), ground_y=71, feet_last_row=70, facing='direita',
    coords='px do canvas, origem no canto superior esquerdo, y para baixo; articulação (x,y) = canto sup. esq. do pixel. unity_pivot normalizado com origem embaixo',
    import_settings=dict(filter='Point (no filter)', compression='None', ppu='100 (provisório, mesmo do projeto)', sprite_mode='Single', pivot='Custom = unity_pivot', mesh='Full Rect'),
    joints_canvas={k: list(v) for k, v in J.items()}, hierarchy=nodes, sprites=spr, render_order=ORDER,
    idle=dict(fps=ID.FPS, loop=True, frames=idle_frames, sheet='idle/croc_idle_sheet.png', sheet_layout='6 quadros 48x72 em linha'),
    blink=dict(overlays=['eyelid_half', 'eyelid_closed'], sequence=[dict(overlay='eyelid_half', ms=60), dict(overlay='eyelid_closed', ms=100), dict(overlay='eyelid_half', ms=60)],
               interval_seconds=[3, 6], independent_of_breathing=True, attach_to='Head',
               frames_preview=['idle/croc_idle_blink_half.png', 'idle/croc_idle_blink_closed.png']),
    underpaint=MO.NOTES,
    validation=dict(rest_reconstruction_diff_px=int(diff.sum()),
                    idle_diff_vs_master_px=[int((f != M).any(-1).sum()) for f in frames]),
)
missing = [s['file'] for s in spr.values() if not os.path.exists(f"{OUT}/{s['file']}")]
for f in idle_frames:
    if not os.path.exists(f"{OUT}/{f['file']}"): missing.append(f['file'])
for p in ('master/croc_hub_master.png', 'idle/croc_idle_sheet.png', 'idle/croc_idle.gif', 'previews/master_native.png', 'previews/master_zoom_nearest.png',
          'previews/modular_exploded.png', 'previews/modular_reconstructed.png', 'previews/original_vs_master.png', 'previews/idle_actual_scale.gif',
          'previews/idle_zoom.gif', 'previews/idle_contact_sheet.png', 'previews/transparency_check.png'):
    if not os.path.exists(f'{OUT}/{p}'): missing.append(p)
man['validation']['missing_files'] = missing
json.dump(man, open(f'{OUT}/croc_hub_manifest.json', 'w'), indent=1, ensure_ascii=False)
for f in ('grid.py', 'sample.py', 'master.py', 'clean.py', 'modules.py', 'idle.py', 'export.py'):
    shutil.copy(f'/home/claude/proj/crochub/{f}', f'{OUT}/tools/{f}')
print('missing', missing, 'diff', int(diff.sum()))
for n, s in spr.items(): print(n, s['w'], s['h'], s['canvas_x'], s['canvas_y'], s['unity_pivot'], s['hidden_underpaint_pixels'])
